package org.leochen.samples.service.user;

import javax.annotation.security.RolesAllowed;

/**
 * User: leochen
 * Date: 11-12-7
 * Time: 下午2:32
 */
public interface CustomUserService extends ChangePassword{

}
