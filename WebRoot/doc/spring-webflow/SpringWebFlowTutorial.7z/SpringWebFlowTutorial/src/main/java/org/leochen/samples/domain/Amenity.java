package org.leochen.samples.domain;

/**
 * User: leochen
 * Date: 11-12-13
 * Time: 下午3:14
 */
public enum Amenity {
    OCEAN_VIEW, LATE_CHECKOUT, MINIBAR;
}
