Here are some Javascript libraries built by JsJava.
1) jsjava-core.js : include jsjava core classes
2) jsjava-ajax.js : include jsjava ajax classes
3) jsjava-anim.js : include jsjava animation classes
4) jsjava-math.js : include jsjava math classes
5) jsjava-blog.js : include jsjava blog classes
6) jsjava-comp.js : include jsjava components classes
7) jsjava-info.js : include jsjava information classes